package com.sasha.tryvohaporuch

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.CancellationSignal
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.util.Locale
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicReference

class AlarmStatusRepository(private val context: Context) {
    private val prefs = context.getSharedPreferences("wear_alarm_state", Context.MODE_PRIVATE)

    fun cached(): AlarmSnapshot {
        if (!prefs.contains("value")) return AlarmSnapshot.unknown()
        return AlarmSnapshot(
            value = prefs.getFloat("value", 0.5f),
            city = prefs.getString("city", "МІСЦЕЗНАХОДЖЕННЯ") ?: "МІСЦЕЗНАХОДЖЕННЯ",
            detail = prefs.getString("detail", "СТАТУС НЕВІДОМИЙ") ?: "СТАТУС НЕВІДОМИЙ",
            startedAt = prefs.getLong("started_at", 0L),
            updatedAt = prefs.getLong("updated_at", 0L)
        )
    }

    fun latest(maxAgeMs: Long = 60_000L): AlarmSnapshot {
        val cached = cached()
        if (cached.updatedAt > 0L && System.currentTimeMillis() - cached.updatedAt <= maxAgeMs) {
            return cached
        }
        return try {
            refresh()
        } catch (_: Exception) {
            if (cached.updatedAt > 0L && System.currentTimeMillis() - cached.updatedAt <= 2L * 60L * 1000L) {
                cached
            } else {
                save(AlarmSnapshot.unknown("НЕМАЄ ЗВ’ЯЗКУ"))
            }
        }
    }

    fun refresh(): AlarmSnapshot {
        val liveLocation = bestLastLocation()
        val livePlace = liveLocation?.let(::reverseGeocode)
        val selected = if (liveLocation != null && livePlace?.isUkraine(liveLocation) == true) {
            val confirmedPlace = livePlace.copy(country = "UA")
            saveLastUkraine(liveLocation, confirmedPlace)
            liveLocation to confirmedPlace
        } else {
            loadLastUkraine()
        } ?: return save(AlarmSnapshot.unknown("НЕМАЄ ЗБЕРЕЖЕНОЇ ЛОКАЦІЇ В УКРАЇНІ"))
        val place = selected.second

        val token = extractToken(get(MAP_URL, null))
        val payload = try {
            get(UPDATE_URL, token)
        } catch (_: UnauthorizedException) {
            get(UPDATE_URL, extractToken(get(MAP_URL, null)))
        }
        val result = parse(payload, place)
        return save(result)
    }

    private fun save(snapshot: AlarmSnapshot): AlarmSnapshot {
        prefs.edit()
            .putFloat("value", snapshot.value)
            .putString("city", snapshot.city)
            .putString("detail", snapshot.detail)
            .putLong("started_at", snapshot.startedAt)
            .putLong("updated_at", snapshot.updatedAt)
            .apply()
        return snapshot
    }

    private fun bestLastLocation(): Location? {
        val fine = context.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = context.checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return null
        val manager = context.getSystemService(LocationManager::class.java) ?: return null
        val lastKnown = manager.allProviders.mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }.filter(::isInsideUkraineBounds)
            .maxWithOrNull(compareBy<Location> { it.time }.thenBy { -it.accuracy })
        if (lastKnown != null && System.currentTimeMillis() - lastKnown.time <= 10L * 60L * 1000L) {
            return lastKnown
        }
        return currentLocation(manager) ?: lastKnown
    }

    private fun currentLocation(manager: LocationManager): Location? {
        val providers = manager.allProviders.filter { provider ->
            try { manager.isProviderEnabled(provider) } catch (_: Exception) { false }
        }
        if (providers.isEmpty()) return null
        val result = AtomicReference<Location?>()
        val latch = CountDownLatch(1)
        for (provider in providers) {
            try {
                manager.getCurrentLocation(provider, CancellationSignal(), context.mainExecutor) { location ->
                    if (location != null && isInsideUkraineBounds(location) &&
                        result.compareAndSet(null, location)) latch.countDown()
                }
            } catch (_: SecurityException) {
                return null
            } catch (_: IllegalArgumentException) {
                // Some watches expose providers that cannot deliver a one-shot fix.
            }
        }
        latch.await(12L, TimeUnit.SECONDS)
        return result.get()
    }

    @Suppress("DEPRECATION")
    private fun reverseGeocode(location: Location): Place? {
        val geocoder = Geocoder(context, Locale("uk", "UA"))
        val address = geocoder.getFromLocation(location.latitude, location.longitude, 1)?.firstOrNull()
            ?: return null
        val city = listOf(address.locality, address.subAdminArea, address.adminArea)
            .firstOrNull { !it.isNullOrBlank() }.orEmpty()
        return Place(city, address.subAdminArea.orEmpty(), address.adminArea.orEmpty(), address.countryCode.orEmpty())
    }

    private fun saveLastUkraine(location: Location, place: Place) {
        prefs.edit()
            .putLong(LAST_UA_LAT, java.lang.Double.doubleToRawLongBits(location.latitude))
            .putLong(LAST_UA_LON, java.lang.Double.doubleToRawLongBits(location.longitude))
            .putString(LAST_UA_CITY, place.city)
            .putString(LAST_UA_DISTRICT, place.district)
            .putString(LAST_UA_REGION, place.region)
            .putLong(LAST_UA_AT, System.currentTimeMillis())
            .apply()
    }

    private fun loadLastUkraine(): Pair<Location, Place>? {
        if (!prefs.contains(LAST_UA_LAT) || !prefs.contains(LAST_UA_LON)) return null
        val latitude = java.lang.Double.longBitsToDouble(prefs.getLong(LAST_UA_LAT, 0L))
        val longitude = java.lang.Double.longBitsToDouble(prefs.getLong(LAST_UA_LON, 0L))
        val location = Location("saved_ukraine").apply {
            this.latitude = latitude
            this.longitude = longitude
            time = prefs.getLong(LAST_UA_AT, 0L)
            accuracy = 1_000f
        }
        if (!isInsideUkraineBounds(location)) return null
        val place = Place(
            prefs.getString(LAST_UA_CITY, "").orEmpty(),
            prefs.getString(LAST_UA_DISTRICT, "").orEmpty(),
            prefs.getString(LAST_UA_REGION, "").orEmpty(),
            "UA"
        )
        return location to place
    }

    private fun isInsideUkraineBounds(location: Location): Boolean =
        location.latitude in 43.8..52.7 && location.longitude in 21.8..40.5

    private fun parse(json: String, place: Place): AlarmSnapshot {
        if (!place.country.equals("UA", true)) {
            return AlarmSnapshot(0.5f, place.city.uppercase(), "ПОЗА УКРАЇНОЮ", 0L, System.currentTimeMillis())
        }
        val alerts = JSONObject(json).optJSONArray("alerts")
            ?: throw IOException("No alerts list")
        var bestScore = 0
        var bestStartedAt = 0L
        var bestName = ""
        for (index in 0 until alerts.length()) {
            val region = alerts.optJSONObject(index) ?: continue
            val startedAt = findAirAlertStart(region.optJSONArray("activeAlerts"))
            if (startedAt == 0L) continue
            val score = matchScore(place, region)
            if (score > bestScore || (score == bestScore && score > 0 && startedAt < bestStartedAt)) {
                bestScore = score
                bestStartedAt = startedAt
                bestName = region.optString("regionName", place.city)
            }
        }
        return if (bestScore > 0) {
            AlarmSnapshot(1f, place.city.uppercase(), "ПОВІТРЯНА ТРИВОГА · $bestName", bestStartedAt, System.currentTimeMillis())
        } else {
            AlarmSnapshot(0f, place.city.uppercase(), "ТРИВОГИ НЕМАЄ", 0L, System.currentTimeMillis())
        }
    }

    private fun findAirAlertStart(active: JSONArray?): Long {
        if (active == null) return 0L
        var earliest = 0L
        for (index in 0 until active.length()) {
            val item = active.optJSONObject(index) ?: continue
            if (!item.optString("type").equals("AIR", true)) continue
            val parsed = try { Instant.parse(item.optString("lastUpdate")).toEpochMilli() } catch (_: Exception) { System.currentTimeMillis() }
            if (earliest == 0L || parsed < earliest) earliest = parsed
        }
        return earliest
    }

    private fun matchScore(place: Place, region: JSONObject): Int {
        val ua = normalize(region.optString("regionName"))
        val en = normalize(region.optString("regionEngName"))
        val type = normalize(region.optString("regionType"))
        val city = normalize(place.city)
        val district = normalize(place.district)
        val state = normalize(place.region)

        if (city == "київ" || city == "киев" || city == "kyiv" || normalize(place.region) in setOf("kyiv city", "місто київ", "м київ")) {
            val exact = ua in setOf("м київ", "київ") || en in setOf("kyiv city", "city of kyiv")
            val wrong = "область" in ua || "район" in ua || "region" in en || "district" in en
            return if (exact && !wrong) 4 else 0
        }
        val cityScoped = "громада" in ua || ua.startsWith("м ") || "community" in en || en.endsWith(" city")
        if (("community" in type || cityScoped) && (loose(ua, city) || loose(en, city))) return 4
        if ("district" in type && (loose(ua, district) || loose(en, district))) return 3
        if ("state" in type && !cityScoped && (loose(ua, state) || loose(en, state))) return 2
        return 0
    }

    private fun loose(source: String, target: String): Boolean {
        if (source.isBlank() || target.isBlank()) return false
        val a = core(source)
        val b = core(target)
        return a == b || a.contains(b) || b.contains(a)
    }

    private fun core(value: String) = normalize(value)
        .replace(Regex("\\b(область|region|oblast|район|district|територіальна|міська|селищна|сільська|громада|community|city|місто|м)\\b"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun normalize(value: String?) = value.orEmpty().lowercase(Locale.ROOT)
        .replace('ё', 'е').replace('’', ' ').replace('\'', ' ')
        .replace(Regex("[^a-zа-яіїєґ0-9]+"), " ")
        .replace(Regex("\\s+"), " ").trim()

    private fun extractToken(html: String): String {
        val match = TOKEN_PATTERN.find(html) ?: throw IOException("No API token")
        return match.groupValues[1]
    }

    private fun get(urlText: String, bearer: String?): String {
        val connection = URL(urlText).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12_000
            connection.readTimeout = 15_000
            connection.useCaches = false
            connection.setRequestProperty("Accept", "application/json,text/html;q=0.9,*/*;q=0.8")
            connection.setRequestProperty("User-Agent", "TryvohaPoruch-Wear/1.1.1")
            if (bearer != null) connection.setRequestProperty("Authorization", "Bearer $bearer")
            if (connection.responseCode == HttpURLConnection.HTTP_UNAUTHORIZED) throw UnauthorizedException()
            if (connection.responseCode !in 200..299) throw IOException("HTTP ${connection.responseCode}")
            return BufferedReader(InputStreamReader(connection.inputStream, StandardCharsets.UTF_8)).use { it.readText() }
        } finally {
            connection.disconnect()
        }
    }

    private data class Place(val city: String, val district: String, val region: String, val country: String) {
        fun isUkraine(location: Location): Boolean =
            country.equals("UA", true) || (country.isBlank() &&
                    location.latitude in 43.8..52.7 && location.longitude in 21.8..40.5)
    }
    private class UnauthorizedException : IOException()

    companion object {
        private const val MAP_URL = "https://map.ukrainealarm.com/"
        private const val UPDATE_URL = "https://map.ukrainealarm.com/api/v2/data/mapUpdate"
        private const val LAST_UA_LAT = "last_ua_lat"
        private const val LAST_UA_LON = "last_ua_lon"
        private const val LAST_UA_CITY = "last_ua_city"
        private const val LAST_UA_DISTRICT = "last_ua_district"
        private const val LAST_UA_REGION = "last_ua_region"
        private const val LAST_UA_AT = "last_ua_at"
        private val TOKEN_PATTERN = Regex("id=[\\\"']api-token[\\\"'][^>]*value=[\\\"']([^\\\"']+)", RegexOption.IGNORE_CASE)
    }
}
