package com.sasha.tryvohaporuch

data class AlarmSnapshot(
    val value: Float,
    val city: String,
    val detail: String,
    val startedAt: Long,
    val updatedAt: Long
) {
    val isAlert: Boolean get() = value >= 0.75f
    val isUnknown: Boolean get() = value in 0.25f..0.74f

    companion object {
        fun unknown(detail: String = "СТАТУС НЕВІДОМИЙ") =
            AlarmSnapshot(0.5f, "МІСЦЕЗНАХОДЖЕННЯ", detail, 0L, System.currentTimeMillis())
    }
}
