package com.sasha.tryvohaporuch

import android.Manifest
import android.app.Activity
import android.content.ComponentName
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import androidx.wear.watchface.complications.datasource.ComplicationDataSourceUpdateRequester
import com.sasha.tryvohaporuch.complication.AlarmComplicationService
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AlarmDetailsActivity : Activity() {
    private lateinit var title: TextView
    private lateinit var detail: TextView
    private lateinit var footer: TextView
    private lateinit var action: Button
    private lateinit var card: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(buildUi())
        action.setOnClickListener {
            if (!hasLocation()) {
                requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 71)
            } else {
                refresh()
            }
        }
        show(AlarmStatusRepository(this).cached())
        if (hasLocation()) refresh()
    }

    private fun buildUi(): LinearLayout {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(24, 28, 24, 28)
            setBackgroundColor(Color.BLACK)
        }
        card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(20, 20, 20, 18)
        }
        title = text(22f, Color.WHITE, true)
        detail = text(14f, Color.WHITE, true)
        footer = text(12f, 0xFFD8D8D8.toInt(), false)
        action = Button(this).apply {
            text = "Оновити"
            isAllCaps = false
        }
        card.addView(title, matchWrap())
        card.addView(detail, matchWrap())
        card.addView(footer, matchWrap())
        root.addView(card, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { setMargins(0, 0, 0, 10) })
        root.addView(action, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        return root
    }

    private fun text(size: Float, color: Int, bold: Boolean) = TextView(this).apply {
        textSize = size
        setTextColor(color)
        gravity = Gravity.CENTER
        setPadding(4, 4, 4, 4)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)

    private fun refresh() {
        action.isEnabled = false
        action.text = "Перевіряю…"
        Thread {
            val snapshot = try { AlarmStatusRepository(this).refresh() } catch (_: Exception) { AlarmSnapshot.unknown("НЕМАЄ ЗВ’ЯЗКУ") }
            runOnUiThread {
                show(snapshot)
                action.isEnabled = true
                action.text = "Оновити"
                ComplicationDataSourceUpdateRequester.create(
                    this,
                    ComponentName(this, AlarmComplicationService::class.java)
                ).requestUpdateAll()
            }
        }.start()
    }

    private fun show(snapshot: AlarmSnapshot) {
        title.text = snapshot.city
        detail.text = snapshot.detail
        footer.text = when {
            snapshot.isAlert && snapshot.startedAt > 0L -> {
                val started = SimpleDateFormat("HH:mm", Locale("uk", "UA")).format(Date(snapshot.startedAt))
                val minutes = ((System.currentTimeMillis() - snapshot.startedAt).coerceAtLeast(0L) / 60_000L)
                "ПОЧАТОК $started · ТРИВАЄ $minutes ХВ"
            }
            snapshot.updatedAt > 0L -> "ОНОВЛЕНО ${SimpleDateFormat("HH:mm", Locale("uk", "UA")).format(Date(snapshot.updatedAt))}"
            else -> "ВІДКРИЙТЕ ДОСТУП ДО ГЕОЛОКАЦІЇ"
        }
        val color = when {
            snapshot.isAlert -> 0xFFB80D20.toInt()
            snapshot.isUnknown -> 0xFF8B5D12.toInt()
            else -> 0xFF08764E.toInt()
        }
        card.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = 28f
            setColor(color)
            setStroke(2, 0xFFD9A759.toInt())
        }
        action.text = if (hasLocation()) "Оновити" else "Дозволити GPS"
    }

    private fun hasLocation(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 71 && hasLocation()) refresh() else show(AlarmSnapshot.unknown("ПОТРІБЕН ДОСТУП ДО GPS"))
    }
}
