package com.sasha.tryvohaporuch.complication

import android.app.PendingIntent
import android.content.Intent
import androidx.wear.watchface.complications.data.ComplicationData
import androidx.wear.watchface.complications.data.ComplicationType
import androidx.wear.watchface.complications.data.PlainComplicationText
import androidx.wear.watchface.complications.data.RangedValueComplicationData
import androidx.wear.watchface.complications.datasource.ComplicationRequest
import androidx.wear.watchface.complications.datasource.SuspendingComplicationDataSourceService
import com.sasha.tryvohaporuch.AlarmDetailsActivity
import com.sasha.tryvohaporuch.AlarmSnapshot
import com.sasha.tryvohaporuch.AlarmStatusRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class AlarmComplicationService : SuspendingComplicationDataSourceService() {
    override suspend fun onComplicationRequest(request: ComplicationRequest): ComplicationData? {
        if (request.complicationType != ComplicationType.RANGED_VALUE) return null
        val snapshot = withContext(Dispatchers.IO) { AlarmStatusRepository(this@AlarmComplicationService).latest() }
        return data(snapshot)
    }

    override fun getPreviewData(type: ComplicationType): ComplicationData? {
        if (type != ComplicationType.RANGED_VALUE) return null
        return data(AlarmSnapshot(0f, "КИЇВ", "ТРИВОГИ НЕМАЄ", 0L, System.currentTimeMillis()))
    }

    private fun data(snapshot: AlarmSnapshot): RangedValueComplicationData {
        val openDetails = PendingIntent.getActivity(
            this,
            7102,
            Intent(this, AlarmDetailsActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val spoken = PlainComplicationText.Builder("${snapshot.city}: ${snapshot.detail}").build()
        return RangedValueComplicationData.Builder(
            value = snapshot.value,
            min = 0f,
            max = 1f,
            contentDescription = spoken
        )
            .setText(PlainComplicationText.Builder(if (snapshot.isAlert) "ТРИВОГА" else if (snapshot.isUnknown) "НЕВІДОМО" else "БЕЗПЕЧНО").build())
            .setTitle(PlainComplicationText.Builder(snapshot.city).build())
            .setTapAction(openDetails)
            .build()
    }
}
