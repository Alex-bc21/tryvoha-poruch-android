plugins {
    id("com.android.application")
}

android {
    namespace = "com.sasha.tryvohaporuch"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.sasha.tryvohaporuch"
        minSdk = 26
        targetSdk = 35
        versionCode = 6
        versionName = "1.0.5"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}
