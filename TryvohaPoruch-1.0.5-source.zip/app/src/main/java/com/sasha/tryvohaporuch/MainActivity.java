package com.sasha.tryvohaporuch;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity {
    private static final int REQUEST_PERMISSIONS = 7001;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView cityView;
    private TextView statusView;
    private TextView threatView;
    private TextView updateView;

    private final Runnable uiUpdater = new Runnable() {
        @Override
        public void run() {
            renderState();
            handler.postDelayed(this, 1_000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(22, 34, 42));
        setContentView(buildContent());

        if (Prefs.get(this).getBoolean(Prefs.ENABLED, false) && hasLocationPermission()) {
            startMonitor(false);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.post(uiUpdater);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(uiUpdater);
        super.onPause();
    }

    private View buildContent() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(22), dp(24), dp(22), dp(24));
        root.setBackgroundColor(Color.rgb(244, 246, 248));

        TextView title = text("Тривога поруч", 28, Color.rgb(22, 34, 42), true);
        root.addView(title, matchWrap());

        TextView intro = text(
                "Вертикальний віджет 1×2 автоматично визначає ваше місцезнаходження, показує статус тривоги, тип актуальної загрози та напрямок її руху.",
                16, Color.rgb(67, 77, 86), false);
        LinearLayout.LayoutParams introParams = matchWrap();
        introParams.topMargin = dp(10);
        root.addView(intro, introParams);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(dp(18), dp(22), dp(18), dp(22));
        card.setBackgroundColor(Color.rgb(55, 71, 79));
        LinearLayout.LayoutParams cardParams = matchWrap();
        cardParams.topMargin = dp(22);
        root.addView(card, cardParams);

        cityView = text("МІСЦЕЗНАХОДЖЕННЯ", 17, Color.WHITE, true);
        cityView.setGravity(Gravity.CENTER);
        card.addView(cityView, matchWrap());

        statusView = text("НАТИСНІТЬ «ЗАПУСТИТИ»", 23, Color.WHITE, true);
        statusView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = matchWrap();
        statusParams.topMargin = dp(12);
        card.addView(statusView, statusParams);

        threatView = text("ТИП ЗАГРОЗИ ТА НАПРЯМОК УТОЧНЮЮТЬСЯ", 15,
                Color.rgb(255, 226, 176), true);
        threatView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams threatParams = matchWrap();
        threatParams.topMargin = dp(10);
        card.addView(threatView, threatParams);

        updateView = text("Статус ще не отримано", 13, Color.argb(210, 255, 255, 255), false);
        updateView.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams updateParams = matchWrap();
        updateParams.topMargin = dp(8);
        card.addView(updateView, updateParams);

        Button start = new Button(this);
        start.setText("Дозволити геолокацію та запустити");
        start.setAllCaps(false);
        start.setOnClickListener(view -> ensurePermissionsAndStart());
        LinearLayout.LayoutParams buttonParams = matchWrap();
        buttonParams.topMargin = dp(20);
        root.addView(start, buttonParams);

        Button refresh = new Button(this);
        refresh.setText("Оновити зараз");
        refresh.setAllCaps(false);
        refresh.setOnClickListener(view -> {
            if (!hasLocationPermission()) {
                ensurePermissionsAndStart();
            } else {
                startMonitor(true);
                Toast.makeText(this, "Оновлюю статус", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(refresh, matchWrap());

        Button addWidget = new Button(this);
        addWidget.setText("Додати віджет на екран");
        addWidget.setAllCaps(false);
        addWidget.setOnClickListener(view -> requestWidgetPin());
        root.addView(addWidget, matchWrap());

        Button settingsButton = new Button(this);
        settingsButton.setText("Відкрити системні налаштування застосунку");
        settingsButton.setAllCaps(false);
        settingsButton.setOnClickListener(view -> {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        });
        root.addView(settingsButton, matchWrap());

        TextView note = text(
                "Статус надходить з офіційної мапи «Повітряна тривога». Оперативний тип загрози та напрямок беруться з публічних повідомлень Повітряних Сил ЗСУ. Координати не передаються на наш сервер. Віджет доповнює, але не замінює сирени й офіційні сповіщення.",
                13, Color.rgb(91, 101, 110), false);
        LinearLayout.LayoutParams noteParams = matchWrap();
        noteParams.topMargin = dp(16);
        root.addView(note, noteParams);
        return root;
    }

    private void ensurePermissionsAndStart() {
        List<String> missing = new ArrayList<>();
        if (!hasLocationPermission()) {
            missing.add(Manifest.permission.ACCESS_FINE_LOCATION);
            missing.add(Manifest.permission.ACCESS_COARSE_LOCATION);
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.POST_NOTIFICATIONS);
        }

        if (missing.isEmpty()) {
            startMonitor(true);
        } else {
            requestPermissions(missing.toArray(new String[0]), REQUEST_PERMISSIONS);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PERMISSIONS) {
            if (hasLocationPermission()) {
                startMonitor(true);
            } else {
                Toast.makeText(this, "Без геолокації неможливо визначити поточне місто",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    private void startMonitor(boolean refreshNow) {
        Intent intent = new Intent(this, AlarmMonitorService.class)
                .setAction(refreshNow ? AlarmMonitorService.ACTION_REFRESH : AlarmMonitorService.ACTION_START);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent);
        } else {
            startService(intent);
        }
        Prefs.get(this).edit().putBoolean(Prefs.ENABLED, true).apply();
    }

    private void requestWidgetPin() {
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
        ComponentName provider = new ComponentName(this, AlarmWidgetProvider.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.isRequestPinAppWidgetSupported()) {
            Intent success = new Intent(this, MainActivity.class);
            PendingIntent callback = PendingIntent.getActivity(this, 702, success,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            manager.requestPinAppWidget(provider, null, callback);
        } else {
            Toast.makeText(this,
                    "Затисніть порожнє місце на екрані → Віджети → Тривога поруч",
                    Toast.LENGTH_LONG).show();
        }
    }

    private void renderState() {
        SharedPreferences prefs = Prefs.get(this);
        String state = prefs.getString(Prefs.STATE, Prefs.UNKNOWN);
        String city = prefs.getString(Prefs.CITY, "МІСЦЕЗНАХОДЖЕННЯ");
        String detail = prefs.getString(Prefs.DETAIL, "НАТИСНІТЬ «ЗАПУСТИТИ»");
        String threatType = prefs.getString(Prefs.THREAT_TYPE, "");
        String threatRoute = prefs.getString(Prefs.THREAT_ROUTE, "");
        long threatReportedAt = prefs.getLong(Prefs.THREAT_REPORTED_AT, 0L);
        long updatedAt = prefs.getLong(Prefs.UPDATED_AT, 0L);

        cityView.setText(city.toUpperCase(Locale.getDefault()));
        statusView.setText(detail);
        if (Prefs.ALERT.equals(state)) {
            String threat = threatType.isBlank() ? "ТИП ЗАГРОЗИ УТОЧНЮЄТЬСЯ" : threatType;
            if (!threatRoute.isBlank()) threat += "\n" + threatRoute;
            if (threatReportedAt > 0L) {
                threat += "\nПС ЗСУ · " + new SimpleDateFormat("HH:mm", Locale.getDefault())
                        .format(new Date(threatReportedAt));
            }
            threatView.setText(threat);
            threatView.setVisibility(View.VISIBLE);
        } else {
            threatView.setVisibility(View.GONE);
        }
        if (updatedAt > 0L) {
            updateView.setText("Оновлено " + new SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                    .format(new Date(updatedAt)));
        } else {
            updateView.setText("Статус ще не отримано");
        }

        int color;
        switch (state) {
            case Prefs.CLEAR: color = Color.rgb(8, 122, 70); break;
            case Prefs.ALERT: color = Color.rgb(180, 35, 24); break;
            case Prefs.LOADING: color = Color.rgb(36, 87, 167); break;
            case Prefs.ERROR: color = Color.rgb(154, 103, 0); break;
            default: color = Color.rgb(55, 71, 79); break;
        }
        ((View) cityView.getParent()).setBackgroundColor(color);
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private TextView text(String value, int sp, int color, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextSize(sp);
        view.setTextColor(color);
        view.setLineSpacing(0f, 1.12f);
        if (bold) view.setTypeface(view.getTypeface(), android.graphics.Typeface.BOLD);
        return view;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
