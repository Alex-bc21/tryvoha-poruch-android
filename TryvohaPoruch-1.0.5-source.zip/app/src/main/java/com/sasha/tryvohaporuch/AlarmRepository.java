package com.sasha.tryvohaporuch;

import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class AlarmRepository {
    private static final String TAG = "AlarmRepository";
    private static final String MAP_URL = "https://map.ukrainealarm.com/";
    private static final String UPDATE_URL = "https://map.ukrainealarm.com/api/v2/data/mapUpdate";
    private static final long TOKEN_TTL_MS = 45L * 60L * 1000L;
    private static final Pattern TOKEN_PATTERN = Pattern.compile(
            "id=[\\\"']api-token[\\\"'][^>]*value=[\\\"']([^\\\"']+)",
            Pattern.CASE_INSENSITIVE);

    private String cachedToken;
    private long tokenLoadedAt;

    Result getStatus(LocationInfo location) throws Exception {
        if (!location.isUkraine()) {
            return Result.outside();
        }

        String json;
        try {
            json = requestUpdate(getToken(false));
        } catch (UnauthorizedException unauthorized) {
            json = requestUpdate(getToken(true));
        }

        JSONObject root = new JSONObject(json);
        JSONArray alerts = root.optJSONArray("alerts");
        if (alerts == null) {
            throw new IOException("Ответ карты не содержит список тревог");
        }

        int bestSpecificity = 0;
        long bestStartedAt = 0L;
        String matchedRegion = "";

        for (int index = 0; index < alerts.length(); index++) {
            JSONObject regionObject = alerts.optJSONObject(index);
            if (regionObject == null) continue;

            long airStartedAt = findAirAlertStart(regionObject.optJSONArray("activeAlerts"));
            if (airStartedAt == 0L) continue;

            int specificity = matchSpecificity(location, regionObject);
            if (specificity > bestSpecificity ||
                    (specificity == bestSpecificity && specificity > 0 &&
                            (bestStartedAt == 0L || airStartedAt < bestStartedAt))) {
                bestSpecificity = specificity;
                bestStartedAt = airStartedAt;
                matchedRegion = regionObject.optString("regionName", "");
            }
        }

        return bestSpecificity > 0
                ? Result.alert(bestStartedAt, matchedRegion)
                : Result.clear();
    }

    private synchronized String getToken(boolean force) throws Exception {
        long now = System.currentTimeMillis();
        if (!force && cachedToken != null && now - tokenLoadedAt < TOKEN_TTL_MS) {
            return cachedToken;
        }

        String html = get(MAP_URL, null);
        Matcher matcher = TOKEN_PATTERN.matcher(html);
        if (!matcher.find()) {
            throw new IOException("Не удалось получить ключ официальной карты");
        }
        cachedToken = matcher.group(1);
        tokenLoadedAt = now;
        return cachedToken;
    }

    private String requestUpdate(String token) throws Exception {
        return get(UPDATE_URL, token);
    }

    private String get(String urlText, String bearerToken) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlText).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(12_000);
            connection.setReadTimeout(15_000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "application/json,text/html;q=0.9,*/*;q=0.8");
            connection.setRequestProperty("User-Agent", "TryvohaPoruch-Android/1.0");
            if (bearerToken != null) {
                connection.setRequestProperty("Authorization", "Bearer " + bearerToken);
                connection.setRequestProperty("Cache-Control", "no-cache");
            }

            int code = connection.getResponseCode();
            if (code == HttpURLConnection.HTTP_UNAUTHORIZED) {
                throw new UnauthorizedException();
            }
            if (code < 200 || code >= 300) {
                throw new IOException("Сервер вернул код " + code);
            }

            return readFully(connection.getInputStream());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readFully(InputStream inputStream) throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(
                inputStream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int count;
            while ((count = reader.read(buffer)) != -1) {
                result.append(buffer, 0, count);
            }
        }
        return result.toString();
    }

    private long findAirAlertStart(JSONArray activeAlerts) {
        if (activeAlerts == null) return 0L;
        long earliest = 0L;
        for (int index = 0; index < activeAlerts.length(); index++) {
            JSONObject alert = activeAlerts.optJSONObject(index);
            if (alert == null || !"AIR".equalsIgnoreCase(alert.optString("type"))) continue;
            long parsed = parseTimestamp(alert.optString("lastUpdate"));
            if (parsed > 0L && (earliest == 0L || parsed < earliest)) earliest = parsed;
        }
        return earliest;
    }

    private long parseTimestamp(String value) {
        try {
            return Instant.parse(value).toEpochMilli();
        } catch (Exception error) {
            Log.w(TAG, "Не удалось прочитать время тревоги", error);
            return System.currentTimeMillis();
        }
    }

    private int matchSpecificity(LocationInfo location, JSONObject regionObject) {
        String type = normalize(regionObject.optString("regionType"));
        String uaName = normalize(regionObject.optString("regionName"));
        String enName = normalize(regionObject.optString("regionEngName"));
        String city = normalize(location.city);
        String district = normalize(location.district);
        String region = normalize(location.region);

        if (isKyivCity(location)) {
            boolean exactKyiv = (uaName.equals("м київ") || uaName.equals("київ") ||
                    enName.equals("kyiv city") || enName.equals("city of kyiv"));
            boolean wrongKyiv = uaName.contains("область") || uaName.contains("район") ||
                    enName.contains("region") || enName.contains("district");
            return exactKyiv && !wrongKyiv ? 4 : 0;
        }

        boolean cityScoped = uaName.contains("громада") || uaName.startsWith("м ") ||
                enName.contains("community") || enName.endsWith(" city") || enName.contains(" and ");

        if ((type.contains("community") || cityScoped) &&
                (looseMatch(uaName, city) || looseMatch(enName, city))) {
            return 4;
        }
        if (type.contains("district") &&
                (looseMatch(uaName, district) || looseMatch(enName, district))) {
            return 3;
        }
        if (type.contains("state") && !cityScoped &&
                (looseMatch(uaName, region) || looseMatch(enName, region))) {
            return 2;
        }
        return 0;
    }

    private boolean isKyivCity(LocationInfo location) {
        String city = normalize(location.city);
        String region = normalize(location.region);
        return city.equals("київ") || city.equals("киев") || city.equals("kyiv") ||
                region.equals("kyiv city") || region.equals("місто київ") || region.equals("м київ");
    }

    private boolean looseMatch(String source, String target) {
        if (source.isBlank() || target.isBlank()) return false;
        String a = core(source);
        String b = core(target);
        if (a.isBlank() || b.isBlank()) return false;
        if (a.equals(b) || a.contains(b) || b.contains(a)) return true;

        String firstA = a.split(" ")[0];
        String firstB = b.split(" ")[0];
        int prefixLength = Math.min(Math.min(firstA.length(), firstB.length()), 5);
        return prefixLength >= 4 && firstA.regionMatches(0, firstB, 0, prefixLength);
    }

    private String core(String value) {
        return normalize(value)
                .replaceAll("\\b(область|region|oblast|район|district|територіальна|міська|селищна|сільська|громада|community|city|місто|м)\\b", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    private String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replace('ё', 'е')
                .replace('’', ' ')
                .replace('\'', ' ')
                .replaceAll("[^a-zа-яіїєґ0-9]+", " ")
                .replaceAll("\\s+", " ")
                .trim();
    }

    static final class Result {
        final boolean alert;
        final boolean outsideUkraine;
        final long startedAt;
        final String matchedRegion;

        private Result(boolean alert, boolean outsideUkraine, long startedAt, String matchedRegion) {
            this.alert = alert;
            this.outsideUkraine = outsideUkraine;
            this.startedAt = startedAt;
            this.matchedRegion = matchedRegion;
        }

        static Result alert(long startedAt, String matchedRegion) {
            return new Result(true, false, startedAt, matchedRegion);
        }

        static Result clear() {
            return new Result(false, false, 0L, "");
        }

        static Result outside() {
            return new Result(false, true, 0L, "");
        }
    }

    private static final class UnauthorizedException extends IOException {}
}
