package com.sasha.tryvohaporuch;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String FILE = "alarm_widget_state";
    static final String ENABLED = "enabled";
    static final String STATE = "state";
    static final String CITY = "city";
    static final String DETAIL = "detail";
    static final String UPDATED_AT = "updated_at";
    static final String LAST_SUCCESS_AT = "last_success_at";
    static final String ALERT_STARTED_AT = "alert_started_at";
    static final String THREAT_TYPE = "threat_type";
    static final String THREAT_ROUTE = "threat_route";
    static final String THREAT_SOURCE = "threat_source";
    static final String THREAT_REPORTED_AT = "threat_reported_at";
    static final String LOCATION_LAT = "location_lat";
    static final String LOCATION_LON = "location_lon";
    static final String LAST_UA_LAT = "last_ua_lat";
    static final String LAST_UA_LON = "last_ua_lon";
    static final String LAST_UA_CITY = "last_ua_city";
    static final String LAST_UA_DISTRICT = "last_ua_district";
    static final String LAST_UA_REGION = "last_ua_region";
    static final String LAST_UA_AT = "last_ua_at";

    static final String UNKNOWN = "unknown";
    static final String LOADING = "loading";
    static final String CLEAR = "clear";
    static final String ALERT = "alert";
    static final String ERROR = "error";
    static final String OUTSIDE = "outside";

    private Prefs() {}

    static SharedPreferences get(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }
}
