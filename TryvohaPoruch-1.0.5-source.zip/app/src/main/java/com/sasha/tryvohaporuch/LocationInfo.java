package com.sasha.tryvohaporuch;

import java.util.Locale;

final class LocationInfo {
    final double latitude;
    final double longitude;
    final String city;
    final String district;
    final String region;
    final String countryCode;

    LocationInfo(double latitude, double longitude, String city, String district,
                 String region, String countryCode) {
        this.latitude = latitude;
        this.longitude = longitude;
        this.city = safe(city);
        this.district = safe(district);
        this.region = safe(region);
        this.countryCode = safe(countryCode).toUpperCase(Locale.ROOT);
    }

    String displayName() {
        if (!city.isBlank()) return city;
        if (!district.isBlank()) return district;
        if (!region.isBlank()) return region;
        return "Місцезнаходження";
    }

    boolean isUkraine() {
        return "UA".equals(countryCode) ||
                (countryCode.isBlank() && isInsideUkraineBounds(latitude, longitude));
    }

    static boolean isInsideUkraineBounds(double latitude, double longitude) {
        return latitude >= 43.8 && latitude <= 52.7 &&
                longitude >= 21.8 && longitude <= 40.5;
    }

    private static String safe(String value) {
        return value == null ? "" : value.trim();
    }
}
