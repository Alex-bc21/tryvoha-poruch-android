package com.sasha.tryvohaporuch;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Build;
import android.os.IBinder;
import android.os.Looper;
import android.text.TextUtils;
import android.util.Log;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

public final class AlarmMonitorService extends Service implements LocationListener {
    static final String ACTION_START = "com.sasha.tryvohaporuch.START";
    static final String ACTION_REFRESH = "com.sasha.tryvohaporuch.SERVICE_REFRESH";
    private static final String TAG = "AlarmMonitorService";
    private static final String CHANNEL_ID = "alarm_status_indicator_v2";
    private static final int NOTIFICATION_ID = 7101;
    private static final long STALE_AFTER_MS = 2L * 60L * 1000L;

    private final ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
    private final AtomicBoolean refreshing = new AtomicBoolean(false);
    private final AlarmRepository repository = new AlarmRepository();
    private final ThreatRepository threatRepository = new ThreatRepository();

    private LocationManager locationManager;
    private volatile Location latestLocation;
    private volatile Location geocodedLocation;
    private volatile LocationInfo locationInfo;
    private volatile long geocodedAt;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        startForeground(NOTIFICATION_ID,
                buildNotification(Prefs.LOADING, "Визначаю місцезнаходження…"));
        Prefs.get(this).edit().putBoolean(Prefs.ENABLED, true).apply();
        startLocationTracking();
        executor.scheduleWithFixedDelay(this::refreshSafely, 0L, 45L, TimeUnit.SECONDS);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_REFRESH.equals(intent.getAction())) {
            executor.execute(this::refreshSafely);
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onLocationChanged(Location location) {
        if (location == null) return;
        if (!LocationInfo.isInsideUkraineBounds(location.getLatitude(), location.getLongitude())) {
            Log.w(TAG, "Ігнорую GPS-стрибок за межі України: " +
                    location.getLatitude() + ", " + location.getLongitude());
            if (latestLocation == null) latestLocation = loadLastUkraineLocation();
            executor.execute(this::refreshSafely);
            return;
        }
        Location current = latestLocation;
        if (current == null || location.getAccuracy() < current.getAccuracy() ||
                location.getTime() > current.getTime()) {
            latestLocation = location;
        }
        if (geocodedLocation == null || geocodedLocation.distanceTo(location) >= 1_000f) {
            executor.execute(this::refreshSafely);
        }
    }

    @Override
    public void onProviderEnabled(String provider) {
        executor.execute(this::refreshSafely);
    }

    @Override
    public void onProviderDisabled(String provider) {
        // Оба провайдера проверяются при следующем обновлении.
    }

    private void startLocationTracking() {
        if (!hasLocationPermission()) {
            publishState(Prefs.ERROR, "ГЕОЛОКАЦІЯ", "ПОТРІБЕН ДОСТУП", 0L, false);
            return;
        }

        locationManager = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        if (locationManager == null) return;

        Location savedUkraineLocation = loadLastUkraineLocation();
        locationInfo = loadLastUkraineLocationInfo();
        geocodedLocation = savedUkraineLocation;
        geocodedAt = Prefs.get(this).getLong(Prefs.LAST_UA_AT, 0L);
        latestLocation = findBestLastLocation();
        if (latestLocation == null) latestLocation = savedUkraineLocation;
        tryRequestUpdates(LocationManager.GPS_PROVIDER);
        tryRequestUpdates(LocationManager.NETWORK_PROVIDER);
        tryRequestUpdates(LocationManager.PASSIVE_PROVIDER);
    }

    private void tryRequestUpdates(String provider) {
        try {
            if (locationManager != null && locationManager.getAllProviders().contains(provider)) {
                locationManager.requestLocationUpdates(provider, 30_000L, 500f, this,
                        Looper.getMainLooper());
            }
        } catch (SecurityException | IllegalArgumentException error) {
            Log.w(TAG, "Не удалось включить провайдер " + provider, error);
        }
    }

    private Location findBestLastLocation() {
        if (!hasLocationPermission() || locationManager == null) return null;
        Location best = null;
        for (String provider : locationManager.getAllProviders()) {
            try {
                Location candidate = locationManager.getLastKnownLocation(provider);
                if (candidate == null || !LocationInfo.isInsideUkraineBounds(
                        candidate.getLatitude(), candidate.getLongitude())) continue;
                if (best == null || candidate.getTime() > best.getTime() ||
                        candidate.getAccuracy() < best.getAccuracy()) {
                    best = candidate;
                }
            } catch (SecurityException ignored) {
                return null;
            }
        }
        return best;
    }

    private void refreshSafely() {
        if (!refreshing.compareAndSet(false, true)) return;
        try {
            refreshNow();
        } catch (Exception error) {
            Log.e(TAG, "Обновление виджета не удалось", error);
            handleRefreshError();
        } finally {
            refreshing.set(false);
        }
    }

    private void refreshNow() throws Exception {
        if (!hasLocationPermission()) {
            publishState(Prefs.ERROR, "ГЕОЛОКАЦІЯ", "ПОТРІБЕН ДОСТУП", 0L, false);
            return;
        }

        Location location = latestLocation;
        if (location == null) {
            location = findBestLastLocation();
            latestLocation = location;
        }
        if (location == null) {
            publishState(Prefs.LOADING, "ШУКАЮ ВАС", "ОЧІКУЮ GPS", 0L, false);
            return;
        }

        if (needsGeocoding(location)) {
            LocationInfo resolved = reverseGeocode(location);
            if (resolved != null && resolved.isUkraine()) {
                locationInfo = resolved;
                geocodedLocation = new Location(location);
                geocodedAt = System.currentTimeMillis();
                saveLastUkraineLocation(location, resolved);
            } else {
                Location fallbackLocation = loadLastUkraineLocation();
                LocationInfo fallbackInfo = loadLastUkraineLocationInfo();
                if (fallbackLocation != null && fallbackInfo != null) {
                    latestLocation = fallbackLocation;
                    geocodedLocation = fallbackLocation;
                    geocodedAt = Prefs.get(this).getLong(Prefs.LAST_UA_AT, 0L);
                    locationInfo = fallbackInfo;
                } else {
                    publishState(Prefs.ERROR, "МІСЦЕЗНАХОДЖЕННЯ",
                            "НЕМАЄ ЗБЕРЕЖЕНОЇ ЛОКАЦІЇ В УКРАЇНІ", 0L, false);
                    return;
                }
            }
        }
        if (locationInfo == null) {
            throw new IllegalStateException("Не удалось определить населённый пункт");
        }

        String display = locationInfo.displayName();
        if (Prefs.get(this).getLong(Prefs.LAST_SUCCESS_AT, 0L) == 0L) {
            publishState(Prefs.LOADING, display, "ПЕРЕВІРЯЮ…", 0L, false);
        }
        AlarmRepository.Result result = repository.getStatus(locationInfo);

        if (result.outsideUkraine) {
            publishState(Prefs.OUTSIDE, display, "ПОЗА УКРАЇНОЮ", 0L, true);
        } else if (result.alert) {
            ThreatRepository.Result threat = ThreatRepository.Result.none();
            try {
                threat = threatRepository.getThreat(locationInfo);
            } catch (Exception error) {
                Log.w(TAG, "Не вдалося оновити оперативний тип загрози", error);
            }
            publishState(Prefs.ALERT, display, "ПОВІТРЯНА ТРИВОГА",
                    result.startedAt, true, threat);
        } else {
            publishState(Prefs.CLEAR, display, "ТРИВОГИ НЕМАЄ", 0L, true);
        }
    }

    private boolean needsGeocoding(Location location) {
        if (locationInfo == null || geocodedLocation == null) return true;
        return geocodedLocation.distanceTo(location) >= 1_000f ||
                System.currentTimeMillis() - geocodedAt > 10L * 60L * 1000L;
    }

    @SuppressWarnings("deprecation")
    private LocationInfo reverseGeocode(Location location) throws Exception {
        Geocoder geocoder = new Geocoder(this, new Locale("uk", "UA"));
        List<Address> addresses = geocoder.getFromLocation(
                location.getLatitude(), location.getLongitude(), 1);
        if (addresses == null || addresses.isEmpty()) return null;

        Address address = addresses.get(0);
        String city = firstNonBlank(address.getLocality(), address.getSubAdminArea(),
                address.getAdminArea());
        return new LocationInfo(
                location.getLatitude(),
                location.getLongitude(),
                city,
                address.getSubAdminArea(),
                address.getAdminArea(),
                address.getCountryCode());
    }

    private String firstNonBlank(String... values) {
        for (String value : values) {
            if (!TextUtils.isEmpty(value) && !value.trim().isEmpty()) return value.trim();
        }
        return "";
    }

    private void saveLastUkraineLocation(Location location, LocationInfo info) {
        Prefs.get(this).edit()
                .putLong(Prefs.LAST_UA_LAT, Double.doubleToRawLongBits(location.getLatitude()))
                .putLong(Prefs.LAST_UA_LON, Double.doubleToRawLongBits(location.getLongitude()))
                .putString(Prefs.LAST_UA_CITY, info.city)
                .putString(Prefs.LAST_UA_DISTRICT, info.district)
                .putString(Prefs.LAST_UA_REGION, info.region)
                .putLong(Prefs.LAST_UA_AT, System.currentTimeMillis())
                .apply();
    }

    private Location loadLastUkraineLocation() {
        SharedPreferences prefs = Prefs.get(this);
        boolean hasConfirmedUkraine = prefs.contains(Prefs.LAST_UA_LAT) &&
                prefs.contains(Prefs.LAST_UA_LON);
        String latitudeKey = hasConfirmedUkraine ? Prefs.LAST_UA_LAT : Prefs.LOCATION_LAT;
        String longitudeKey = hasConfirmedUkraine ? Prefs.LAST_UA_LON : Prefs.LOCATION_LON;
        if (!prefs.contains(latitudeKey) || !prefs.contains(longitudeKey)) return null;
        double latitude = Double.longBitsToDouble(prefs.getLong(latitudeKey, 0L));
        double longitude = Double.longBitsToDouble(prefs.getLong(longitudeKey, 0L));
        if (!LocationInfo.isInsideUkraineBounds(latitude, longitude)) return null;
        Location location = new Location("saved_ukraine");
        location.setLatitude(latitude);
        location.setLongitude(longitude);
        location.setTime(prefs.getLong(
                hasConfirmedUkraine ? Prefs.LAST_UA_AT : Prefs.UPDATED_AT, 0L));
        location.setAccuracy(1_000f);
        return location;
    }

    private LocationInfo loadLastUkraineLocationInfo() {
        SharedPreferences prefs = Prefs.get(this);
        Location location = loadLastUkraineLocation();
        if (location == null) return null;
        return new LocationInfo(
                location.getLatitude(),
                location.getLongitude(),
                prefs.getString(Prefs.LAST_UA_CITY, prefs.getString(Prefs.CITY, "")),
                prefs.getString(Prefs.LAST_UA_DISTRICT, ""),
                prefs.getString(Prefs.LAST_UA_REGION, ""),
                "UA");
    }

    private void handleRefreshError() {
        SharedPreferences prefs = Prefs.get(this);
        long lastSuccess = prefs.getLong(Prefs.LAST_SUCCESS_AT, 0L);
        String previousState = prefs.getString(Prefs.STATE, Prefs.UNKNOWN);
        String city = prefs.getString(Prefs.CITY, "МІСЦЕЗНАХОДЖЕННЯ");
        long age = System.currentTimeMillis() - lastSuccess;

        if (Prefs.ALERT.equals(previousState)) {
            prefs.edit().putString(Prefs.DETAIL, "ТРИВОГА · НЕМАЄ ЗВ’ЯЗКУ").apply();
        } else if (lastSuccess == 0L || age > STALE_AFTER_MS) {
            publishState(Prefs.ERROR, city, "СТАТУС НЕВІДОМИЙ", 0L, false);
            return;
        }
        AlarmWidgetProvider.updateAll(this);
        updateNotificationFromPrefs();
    }

    private void publishState(String state, String city, String detail, long alertStartedAt,
                              boolean successfulUpdate) {
        publishState(state, city, detail, alertStartedAt, successfulUpdate,
                ThreatRepository.Result.none());
    }

    private void publishState(String state, String city, String detail, long alertStartedAt,
                              boolean successfulUpdate, ThreatRepository.Result threat) {
        long now = System.currentTimeMillis();
        SharedPreferences preferences = Prefs.get(this);
        SharedPreferences.Editor editor = preferences.edit()
                .putBoolean(Prefs.ENABLED, true)
                .putString(Prefs.STATE, state)
                .putString(Prefs.CITY, city)
                .putString(Prefs.DETAIL, detail)
                .putLong(Prefs.ALERT_STARTED_AT, alertStartedAt);

        if (successfulUpdate) {
            editor.putLong(Prefs.UPDATED_AT, now).putLong(Prefs.LAST_SUCCESS_AT, now);
        }
        if (!Prefs.ALERT.equals(state)) {
            editor.remove(Prefs.THREAT_TYPE)
                    .remove(Prefs.THREAT_ROUTE)
                    .remove(Prefs.THREAT_SOURCE)
                    .remove(Prefs.THREAT_REPORTED_AT);
        } else if (threat != null && threat.available) {
            editor.putString(Prefs.THREAT_TYPE, threat.type)
                    .putString(Prefs.THREAT_ROUTE, threat.route)
                    .putString(Prefs.THREAT_SOURCE, threat.source)
                    .putLong(Prefs.THREAT_REPORTED_AT, threat.reportedAt);
        } else {
            long previousThreatAt = preferences.getLong(Prefs.THREAT_REPORTED_AT, 0L);
            if (previousThreatAt == 0L || now - previousThreatAt > 10L * 60L * 1000L) {
                editor.remove(Prefs.THREAT_TYPE)
                        .remove(Prefs.THREAT_ROUTE)
                        .remove(Prefs.THREAT_SOURCE)
                        .remove(Prefs.THREAT_REPORTED_AT);
            }
        }
        Location location = latestLocation;
        if (location != null) {
            editor.putLong(Prefs.LOCATION_LAT, Double.doubleToRawLongBits(location.getLatitude()))
                    .putLong(Prefs.LOCATION_LON, Double.doubleToRawLongBits(location.getLongitude()));
        }
        editor.apply();
        AlarmWidgetProvider.updateAll(this);
        updateNotificationFromPrefs();
    }

    private boolean hasLocationPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void createNotificationChannel() {
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID,
                "Постійний індикатор тривоги", NotificationManager.IMPORTANCE_LOW);
        channel.setDescription("Показує стан тривоги у верхньому рядку та підтримує віджет актуальним");
        channel.setShowBadge(false);
        channel.enableVibration(false);
        channel.setSound(null, null);
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.createNotificationChannel(channel);
    }

    private Notification buildNotification(String state, String content) {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder builder = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(statusIcon(state))
                .setColor(statusColor(state))
                .setColorized(false)
                .setContentTitle(statusTitle(state))
                .setContentText(content)
                .setContentIntent(pendingIntent)
                .setOngoing(true)
                .setCategory(Notification.CATEGORY_SERVICE)
                .setOnlyAlertOnce(true)
                .setShowWhen(false)
                .setVisibility(Notification.VISIBILITY_PUBLIC);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            builder.setForegroundServiceBehavior(Notification.FOREGROUND_SERVICE_IMMEDIATE);
        }
        return builder.build();
    }

    private void updateNotificationFromPrefs() {
        SharedPreferences prefs = Prefs.get(this);
        String city = prefs.getString(Prefs.CITY, "Місцезнаходження");
        String detail = prefs.getString(Prefs.DETAIL, "Оновлюю…");
        String state = prefs.getString(Prefs.STATE, Prefs.UNKNOWN);
        String threat = prefs.getString(Prefs.THREAT_TYPE, "");
        if (!threat.isBlank() && Prefs.ALERT.equals(state)) {
            detail += " · " + threat;
        }
        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager != null) manager.notify(NOTIFICATION_ID,
                buildNotification(state, city + ": " + detail.toLowerCase(Locale.ROOT)));
    }

    private int statusIcon(String state) {
        if (Prefs.ALERT.equals(state)) return R.drawable.ic_status_alert;
        if (Prefs.CLEAR.equals(state)) return R.drawable.ic_status_clear;
        return R.drawable.ic_status_unknown;
    }

    private int statusColor(String state) {
        if (Prefs.ALERT.equals(state)) return Color.rgb(255, 38, 61);
        if (Prefs.CLEAR.equals(state)) return Color.rgb(0, 213, 118);
        return Color.rgb(242, 169, 31);
    }

    private String statusTitle(String state) {
        if (Prefs.ALERT.equals(state)) return "Повітряна тривога";
        if (Prefs.CLEAR.equals(state)) return "Тривоги немає";
        return "Статус уточнюється";
    }

    @Override
    public void onDestroy() {
        if (locationManager != null) {
            try {
                locationManager.removeUpdates(this);
            } catch (SecurityException ignored) {
                // Разрешение могло быть отозвано во время работы.
            }
        }
        executor.shutdownNow();
        super.onDestroy();
    }
}
