package com.sasha.tryvohaporuch;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Reads recent public operational notices from the official Air Force channel. */
final class ThreatRepository {
    private static final String CHANNEL_URL = "https://t.me/s/kpszsu";
    private static final long FRESH_MS = 10L * 60L * 1000L;
    private static final long HTML_CACHE_MS = 25L * 1000L;

    private static final Pattern BLOCK_PATTERN = Pattern.compile(
            "<div[^>]+class=\"[^\"]*tgme_widget_message_wrap[^\"]*\"[\\s\\S]*?(?=<div[^>]+class=\"[^\"]*tgme_widget_message_wrap|</section>|$)",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TEXT_PATTERN = Pattern.compile(
            "<div[^>]+class=\"[^\"]*tgme_widget_message_text[^\"]*\"[^>]*>([\\s\\S]*?)</div>",
            Pattern.CASE_INSENSITIVE);
    private static final Pattern TIME_PATTERN = Pattern.compile(
            "<time[^>]+datetime=\"([^\"]+)\"", Pattern.CASE_INSENSITIVE);
    private static final Pattern ENTITY_PATTERN = Pattern.compile("&#(x?[0-9a-fA-F]+);");
    private static final Pattern DIRECTION_PATTERN = Pattern.compile(
            "(?:курс(?:ом)?|у\\s+напрямку|в\\s+напрямку)\\s+(?:на\\s+)?([^,!;\\n]{2,64})",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern FROM_PATTERN = Pattern.compile(
            "(?:^|\\s)з\\s+([^,.!;\\n]{2,48}?)(?=\\s+(?:курс(?:ом)?|у\\s+напрямку|в\\s+напрямку))",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);
    private static final Pattern PLACE_BEFORE_COURSE_PATTERN = Pattern.compile(
            "(?:на|над)\\s+([^,.!;\\n]{2,42})[, ]+\\s*(?:курс(?:ом)?|у\\s+напрямку|в\\s+напрямку)",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    private String cachedHtml;
    private long htmlLoadedAt;

    Result getThreat(LocationInfo location) throws Exception {
        long now = System.currentTimeMillis();
        String html;
        synchronized (this) {
            if (cachedHtml != null && now - htmlLoadedAt < HTML_CACHE_MS) {
                html = cachedHtml;
            } else {
                html = get(CHANNEL_URL);
                cachedHtml = html;
                htmlLoadedAt = now;
            }
        }
        return parse(html, location, now);
    }

    static Result parse(String html, LocationInfo location, long now) {
        if (html == null || html.isBlank() || location == null) return Result.none();

        List<Message> messages = readMessages(html);
        Result best = Result.none();
        int bestScore = Integer.MIN_VALUE;

        for (Message message : messages) {
            long age = now - message.reportedAt;
            if (message.reportedAt <= 0L || age < -60_000L || age > FRESH_MS) continue;

            String type = classify(message.text);
            if (type.isBlank() || isAfterActionSummary(message.text)) continue;

            int relevance = relevance(message.text, location);
            if (relevance == 0) continue;

            int priority = priority(type);
            int recency = (int) Math.max(0L, (FRESH_MS - age) / 60_000L);
            int score = relevance * 100 + priority * 10 + recency;
            if (score > bestScore) {
                bestScore = score;
                best = new Result(true, type, route(message.text, location),
                        "ПС ЗСУ", message.reportedAt);
            }
        }
        return best;
    }

    private static List<Message> readMessages(String html) {
        List<Message> result = new ArrayList<>();
        Matcher blocks = BLOCK_PATTERN.matcher(html);
        while (blocks.find()) {
            String block = blocks.group();
            Matcher textMatcher = TEXT_PATTERN.matcher(block);
            Matcher timeMatcher = TIME_PATTERN.matcher(block);
            if (!textMatcher.find() || !timeMatcher.find()) continue;
            String text = htmlText(textMatcher.group(1));
            long timestamp = parseTimestamp(timeMatcher.group(1));
            if (!text.isBlank() && timestamp > 0L) result.add(new Message(text, timestamp));
        }
        return result;
    }

    private static String classify(String text) {
        String value = normalize(text);
        if (value.contains("баліст") || value.contains("искандер м") || value.contains("іскандер м") || value.contains("kn 23")) {
            return "БАЛІСТИЧНА ЗАГРОЗА";
        }
        if (value.contains("каб") || value.contains("керован") && value.contains("авіабомб")) {
            return "КАБ";
        }
        if (value.contains("ракет") || value.contains("калібр") || value.contains("искандер к") || value.contains("іскандер к") ||
                value.contains("х 101") || value.contains("х 59") || value.contains("онікс")) {
            return "КРИЛАТІ РАКЕТИ";
        }
        if (value.contains("бпла") || value.contains("shahed") || value.contains("шахед") ||
                value.contains("гербер") || value.contains("дрон")) {
            return "УДАРНІ БПЛА";
        }
        if (value.contains("міг 31") || value.contains("ту 95") || value.contains("авіаційн")) {
            return "АВІАЦІЙНА ЗАГРОЗА";
        }
        return "";
    }

    private static boolean isAfterActionSummary(String text) {
        String value = normalize(text);
        return (value.contains("станом на") || value.contains("зафіксовано влучання")) &&
                (value.contains("збито") || value.contains("подавлено") || value.contains("влучання"));
    }

    private static int priority(String type) {
        if (type.startsWith("БАЛІСТ")) return 5;
        if (type.startsWith("КРИЛАТ")) return 4;
        if (type.equals("КАБ")) return 3;
        if (type.startsWith("УДАРН")) return 2;
        return 1;
    }

    private static int relevance(String text, LocationInfo location) {
        String value = normalize(text);
        String city = core(location.city);
        String region = core(location.region);

        if (isKyiv(location) && value.contains("київ")) return 5;
        if (!city.isBlank() && value.contains(city)) return 5;
        if (!region.isBlank() && value.contains(region)) return 4;
        if (value.contains("по всій території україни") ||
                value.contains("вся територія україни") || value.contains("загроза для всієї україни")) {
            return 2;
        }
        if (value.contains("загроза застосування") || value.contains("ракетна небезпека")) {
            return 1;
        }
        return 0;
    }

    private static boolean isKyiv(LocationInfo location) {
        String city = normalize(location.city);
        String region = normalize(location.region);
        return city.equals("київ") || city.equals("киев") || city.equals("kyiv") ||
                region.contains("kyiv city") || region.contains("місто київ") || region.equals("м київ");
    }

    private static String route(String text, LocationInfo location) {
        String oneLine = text.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        Matcher direction = DIRECTION_PATTERN.matcher(oneLine);
        if (direction.find()) {
            String destination = cleanFragment(direction.group(1));
            Matcher from = FROM_PATTERN.matcher(oneLine);
            if (from.find() && from.start() < direction.start()) {
                return fit("З " + cleanFragment(from.group(1)) + " → " + destination, 82);
            }
            Matcher before = PLACE_BEFORE_COURSE_PATTERN.matcher(oneLine);
            String origin = "";
            while (before.find() && before.start() < direction.start()) origin = cleanFragment(before.group(1));
            return fit((origin.isBlank() ? "" : origin + " ") + "→ " + destination, 82);
        }

        String normalized = normalize(oneLine);
        if (normalized.contains("над містом") || normalized.contains("над києвом")) {
            return "НАД " + location.displayName().toUpperCase(Locale.forLanguageTag("uk-UA"));
        }
        return fit(oneLine, 82);
    }

    private static String cleanFragment(String value) {
        return value.replaceAll("^[\\s:–—-]+|[\\s:–—-]+$", "")
                .replaceAll("[.]+$", "")
                .replaceAll("(?i)^(?:реактивні\\s+)?(?:ударні\\s+)?(?:бпла|дрони?|ракети?)\\s+", "")
                .replaceAll("\\s+", " ").trim();
    }

    private static String fit(String value, int max) {
        String clean = value.replaceAll("\\s+", " ").trim();
        if (clean.length() <= max) return clean;
        int cut = clean.lastIndexOf(' ', max - 1);
        if (cut < max / 2) cut = max - 1;
        return clean.substring(0, cut).trim() + "…";
    }

    private static String htmlText(String html) {
        String value = html
                .replaceAll("(?i)<br\\s*/?>", "\\n")
                .replaceAll("(?i)</p>", "\\n")
                .replaceAll("<[^>]+>", " ")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&#39;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">");
        Matcher matcher = ENTITY_PATTERN.matcher(value);
        StringBuffer decoded = new StringBuffer();
        while (matcher.find()) {
            try {
                String number = matcher.group(1);
                int codePoint = number.startsWith("x") || number.startsWith("X")
                        ? Integer.parseInt(number.substring(1), 16)
                        : Integer.parseInt(number, 10);
                matcher.appendReplacement(decoded, Matcher.quoteReplacement(
                        new String(Character.toChars(codePoint))));
            } catch (Exception ignored) {
                matcher.appendReplacement(decoded, " ");
            }
        }
        matcher.appendTail(decoded);
        return decoded.toString().replaceAll("[ \\t]+", " ")
                .replaceAll(" *\\n *", "\\n").trim();
    }

    private static long parseTimestamp(String value) {
        try {
            return Instant.parse(value).toEpochMilli();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    private static String core(String value) {
        return normalize(value)
                .replaceAll("\\b(область|region|oblast|район|district|територіальна|міська|селищна|сільська|громада|community|city|місто|м)\\b", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private static String normalize(String value) {
        if (value == null) return "";
        return value.toLowerCase(Locale.ROOT)
                .replace('ё', 'е').replace('’', ' ').replace('\'', ' ')
                .replaceAll("[^a-zа-яіїєґ0-9]+", " ")
                .replaceAll("\\s+", " ").trim();
    }

    private String get(String urlText) throws Exception {
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(urlText).openConnection();
            connection.setRequestMethod("GET");
            connection.setConnectTimeout(10_000);
            connection.setReadTimeout(12_000);
            connection.setUseCaches(false);
            connection.setRequestProperty("Accept", "text/html,application/xhtml+xml");
            connection.setRequestProperty("Accept-Language", "uk-UA,uk;q=0.9,en;q=0.7");
            connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 16) AppleWebKit/537.36 Chrome/136 Mobile Safari/537.36");
            int code = connection.getResponseCode();
            if (code < 200 || code >= 300) throw new IOException("Канал ПС ЗСУ повернув код " + code);
            return readFully(connection.getInputStream());
        } finally {
            if (connection != null) connection.disconnect();
        }
    }

    private String readFully(InputStream inputStream) throws IOException {
        StringBuilder result = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream, StandardCharsets.UTF_8))) {
            char[] buffer = new char[8192];
            int count;
            while ((count = reader.read(buffer)) != -1) result.append(buffer, 0, count);
        }
        return result.toString();
    }

    static final class Result {
        final boolean available;
        final String type;
        final String route;
        final String source;
        final long reportedAt;

        private Result(boolean available, String type, String route, String source, long reportedAt) {
            this.available = available;
            this.type = type;
            this.route = route;
            this.source = source;
            this.reportedAt = reportedAt;
        }

        static Result none() {
            return new Result(false, "", "", "", 0L);
        }
    }

    private static final class Message {
        final String text;
        final long reportedAt;

        Message(String text, long reportedAt) {
            this.text = text;
            this.reportedAt = reportedAt;
        }
    }
}
