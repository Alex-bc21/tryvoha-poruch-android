package com.sasha.tryvohaporuch;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;

public final class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences prefs = Prefs.get(context);
        if (!prefs.getBoolean(Prefs.ENABLED, false)) return;

        prefs.edit()
                .putString(Prefs.STATE, Prefs.ERROR)
                .putString(Prefs.DETAIL, "ОНОВЛЮЮ ПІСЛЯ ЗАПУСКУ")
                .putLong(Prefs.ALERT_STARTED_AT, 0L)
                .putLong(Prefs.UPDATED_AT, 0L)
                .apply();
        AlarmWidgetProvider.updateAll(context);

        Intent service = new Intent(context, AlarmMonitorService.class)
                .setAction(AlarmMonitorService.ACTION_START);
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(service);
            } else {
                context.startService(service);
            }
        } catch (RuntimeException ignored) {
            // Після системного force-stop Android дозволить запуск при відкритті застосунку.
        }
    }
}
