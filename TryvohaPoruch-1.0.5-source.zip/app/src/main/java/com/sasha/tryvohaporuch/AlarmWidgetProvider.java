package com.sasha.tryvohaporuch;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.view.View;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public final class AlarmWidgetProvider extends AppWidgetProvider {
    static final String ACTION_REFRESH = "com.sasha.tryvohaporuch.REFRESH";

    @Override
    public void onUpdate(Context context, AppWidgetManager appWidgetManager, int[] appWidgetIds) {
        for (int appWidgetId : appWidgetIds) {
            appWidgetManager.updateAppWidget(appWidgetId, buildViews(context));
        }
    }

    @Override
    public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        if (ACTION_REFRESH.equals(intent.getAction())) {
            SharedPreferences prefs = Prefs.get(context);
            if (!prefs.getBoolean(Prefs.ENABLED, false)) {
                Intent open = new Intent(context, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(open);
                return;
            }
            Intent service = new Intent(context, AlarmMonitorService.class)
                    .setAction(AlarmMonitorService.ACTION_REFRESH);
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    context.startForegroundService(service);
                } else {
                    context.startService(service);
                }
            } catch (RuntimeException blockedBySystem) {
                Intent open = new Intent(context, MainActivity.class)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(open);
            }
            updateAll(context);
        }
    }

    static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName provider = new ComponentName(context, AlarmWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(provider);
        for (int id : ids) manager.updateAppWidget(id, buildViews(context));
    }

    private static RemoteViews buildViews(Context context) {
        SharedPreferences prefs = Prefs.get(context);
        String state = prefs.getString(Prefs.STATE, Prefs.UNKNOWN);
        String city = prefs.getString(Prefs.CITY, "ЛОКАЦІЯ");
        long updatedAt = prefs.getLong(Prefs.UPDATED_AT, 0L);
        long alertStartedAt = prefs.getLong(Prefs.ALERT_STARTED_AT, 0L);
        String threatType = prefs.getString(Prefs.THREAT_TYPE, "");
        String threatRoute = prefs.getString(Prefs.THREAT_ROUTE, "");
        String threatSource = prefs.getString(Prefs.THREAT_SOURCE, "ПС ЗСУ");
        long threatReportedAt = prefs.getLong(Prefs.THREAT_REPORTED_AT, 0L);

        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_alarm);
        views.setTextViewText(R.id.widget_city, compactCity(city).toUpperCase(Locale.getDefault()));

        int background;
        String status;
        switch (state) {
            case Prefs.CLEAR:
                background = R.drawable.widget_bg_clear;
                status = "ТРИВОГИ\nНЕМАЄ";
                break;
            case Prefs.ALERT:
                background = R.drawable.widget_bg_alert;
                status = "ПОВІТРЯНА\nТРИВОГА";
                break;
            case Prefs.LOADING:
                background = R.drawable.widget_bg_loading;
                status = "ОНОВЛЕННЯ…";
                break;
            case Prefs.ERROR:
                background = R.drawable.widget_bg_error;
                status = "НЕМАЄ\nДАНИХ";
                break;
            case Prefs.OUTSIDE:
                background = R.drawable.widget_bg_unknown;
                status = "ПОЗА\nУКРАЇНОЮ";
                break;
            default:
                background = R.drawable.widget_bg_unknown;
                status = "НАТИСНІТЬ ↻\nДЛЯ ЗАПУСКУ";
                break;
        }
        views.setInt(R.id.widget_root, "setBackgroundResource", background);
        views.setTextViewText(R.id.widget_status, status);

        boolean showThreat = Prefs.ALERT.equals(state);
        views.setViewVisibility(R.id.widget_threat_panel, showThreat ? View.VISIBLE : View.GONE);
        if (showThreat) {
            if (threatType == null || threatType.isBlank()) {
                views.setTextViewText(R.id.widget_threat_type, "ТИП ЗАГРОЗИ УТОЧНЮЄТЬСЯ");
                views.setTextViewText(R.id.widget_threat_route, "ОЧІКУЮ ПОВІДОМЛЕННЯ ПС ЗСУ");
                views.setTextViewText(R.id.widget_threat_meta, "ОФІЦІЙНЕ ДЖЕРЕЛО · ПС ЗСУ");
            } else {
                views.setTextViewText(R.id.widget_threat_type, threatType);
                views.setTextViewText(R.id.widget_threat_route,
                        threatRoute == null || threatRoute.isBlank() ? "НАПРЯМОК УТОЧНЮЄТЬСЯ" : threatRoute);
                long age = Math.max(0L, System.currentTimeMillis() - threatReportedAt);
                String prefix = age > 10L * 60L * 1000L ? "ДАНІ ЗАСТАРІЛИ" : threatSource;
                views.setTextViewText(R.id.widget_threat_meta,
                        prefix + (threatReportedAt > 0L ? " · " + time(threatReportedAt) : ""));
            }
        }

        String footer;
        if (Prefs.ALERT.equals(state) && alertStartedAt > 0L) {
            long minutes = Math.max(0L, TimeUnit.MILLISECONDS.toMinutes(
                    System.currentTimeMillis() - alertStartedAt));
            footer = "ПОЧАТОК " + time(alertStartedAt) + "\nТРИВАЄ " + minutes + " ХВ";
        } else if (updatedAt > 0L) {
            footer = "ОНОВЛЕНО\n" + time(updatedAt);
        } else {
            footer = "НАТИСНІТЬ ↻";
        }
        views.setTextViewText(R.id.widget_updated, footer);

        Intent open = new Intent(context, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(context, 100, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, openPending);

        Intent refresh = new Intent(context, AlarmWidgetProvider.class).setAction(ACTION_REFRESH);
        PendingIntent refreshPending = PendingIntent.getBroadcast(context, 101, refresh,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_refresh, refreshPending);
        return views;
    }

    private static String compactCity(String city) {
        if (city == null || city.isBlank()) return "ЛОКАЦІЯ";
        return city.replace("територіальна громада", "")
                .replace("міська громада", "")
                .trim();
    }

    private static String time(long timestamp) {
        return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(timestamp));
    }
}
