#!/usr/bin/env bash
set -euo pipefail

TASK_ROOT="$(cd "$(dirname "$0")" && pwd)"
TASK_SDK="${ANDROID_SDK_ROOT:-$TASK_ROOT/../android-tools/sdk}"
TASK_BUILD="$TASK_ROOT/build/manual"
TASK_TOOLS="$TASK_SDK/build-tools/35.0.0"
TASK_PLATFORM="$TASK_SDK/platforms/android-35/android.jar"
TASK_KEY="$TASK_ROOT/signing/tryvoha-poruch.keystore"
TASK_D8="$TASK_TOOLS/d8"

mkdir -p "$TASK_BUILD/compiled" "$TASK_BUILD/generated" "$TASK_BUILD/classes" \
  "$TASK_BUILD/dex" "$TASK_ROOT/app/build/outputs/apk/debug" "$TASK_ROOT/signing"

"$TASK_TOOLS/aapt2" compile --dir "$TASK_ROOT/app/src/main/res" \
  -o "$TASK_BUILD/compiled/resources.zip"

"$TASK_TOOLS/aapt2" link \
  -I "$TASK_PLATFORM" \
  --manifest "$TASK_ROOT/app/src/main/AndroidManifest.xml" \
  --java "$TASK_BUILD/generated" \
  --min-sdk-version 26 \
  --target-sdk-version 35 \
  --version-code 6 \
  --version-name 1.0.5 \
  -o "$TASK_BUILD/app-unsigned-unaligned.apk" \
  "$TASK_BUILD/compiled/resources.zip"

find "$TASK_ROOT/app/src/main/java" "$TASK_BUILD/generated" -name '*.java' -print0 | \
  xargs -0 java -m jdk.compiler/com.sun.tools.javac.Main \
  -encoding UTF-8 -source 17 -target 17 \
  -classpath "$TASK_PLATFORM" -d "$TASK_BUILD/classes"

find "$TASK_BUILD/classes" -name '*.class' -print0 | \
  xargs -0 "$TASK_D8" --min-api 26 --lib "$TASK_PLATFORM" --output "$TASK_BUILD/dex"

zip -q -j "$TASK_BUILD/app-unsigned-unaligned.apk" "$TASK_BUILD/dex/classes.dex"
"$TASK_TOOLS/zipalign" -f -p 4 \
  "$TASK_BUILD/app-unsigned-unaligned.apk" "$TASK_BUILD/app-unsigned.apk"

if [[ ! -f "$TASK_KEY" ]]; then
  keytool -genkeypair -v \
    -keystore "$TASK_KEY" \
    -storepass android -keypass android \
    -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Tryvoha Poruch, O=Local Build, C=UA" -noprompt >/dev/null
fi

"$TASK_TOOLS/apksigner" sign \
  --ks "$TASK_KEY" \
  --ks-key-alias androiddebugkey \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$TASK_ROOT/app/build/outputs/apk/debug/TryvohaPoruch-Phone-1.0.5.apk" \
  "$TASK_BUILD/app-unsigned.apk"

"$TASK_TOOLS/apksigner" verify --verbose \
  "$TASK_ROOT/app/build/outputs/apk/debug/TryvohaPoruch-Phone-1.0.5.apk"
