# Design QA — phone widget 1.0.5

## Source of truth

- Physical-watch feedback and the approved premium visual direction from the conversation.
- Native Android widget layout: `app/src/main/res/layout/widget_alarm.xml`.
- Safety hierarchy: place, alarm state, threat details, timing/source.

## Fidelity checks

- Golden-ratio vertical structure is exact in the alert state: 1.46 / 2.36 / 1.46 / 0.90 = 6.18.
- City and alarm state remain the largest text; threat type and route are subordinate but readable.
- All text is centered inside its allocated region and bounded with `maxLines` plus ellipsis.
- The threat panel appears only during an active alarm; it cannot misrepresent a clear state.
- Missing or stale operational data has an explicit truthful fallback instead of a guessed threat.
- Source and report time stay visible under the route.
- Refresh control remains in the top safe corner and does not overlap the centered status hierarchy.

## Build checks

- Parser fixture test: passed.
- Android resource compilation and Java compilation: passed.
- APK packaging and v2/v3 signature verification: passed.
- Notification states are mapped to three distinct monochrome status-bar forms.
- Foreground notification remains ongoing and requests immediate display on Android 12+.
- Notification channel is silent, low-importance, public on the lock screen, and badge-free.
- Boot and package-replacement receiver attempts to restore the monitor automatically.
- Package/version: `com.sasha.tryvohaporuch`, versionCode 6, versionName 1.0.5.
- Signing certificate SHA-256 matches version 1.0.4, so in-place update is supported.

## Result

Passed. Final physical-screen acceptance should be checked on the user's Samsung launcher because widget cell padding is launcher-dependent.
