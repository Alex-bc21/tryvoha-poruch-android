package com.sasha.tryvohaporuch;

import java.time.Instant;

public final class ThreatRepositorySelfTest {
    public static void main(String[] args) {
        long now = Instant.parse("2026-09-02T04:10:00Z").toEpochMilli();
        LocationInfo kyiv = new LocationInfo(50.45, 30.52, "Київ", "", "м. Київ", "UA");

        String html = """
                <section>
                  <div class="tgme_widget_message_wrap js-widget_message_wrap">
                    <div class="tgme_widget_message_text js-message_text">🏍 Реактивні БпЛА з Чернігівщини курсом на Київщину.</div>
                    <time datetime="2026-09-02T04:07:00+00:00"></time>
                  </div>
                </section>
                """;

        ThreatRepository.Result result = ThreatRepository.parse(html, kyiv, now);
        require(result.available, "fresh Kyiv threat must be available");
        require("УДАРНІ БПЛА".equals(result.type), "threat type must be classified");
        require(result.route.contains("→") && result.route.toLowerCase().contains("київ"),
                "direction must contain Kyiv destination");
        require(result.reportedAt == Instant.parse("2026-09-02T04:07:00Z").toEpochMilli(),
                "source timestamp must be preserved");

        ThreatRepository.Result stale = ThreatRepository.parse(html, kyiv,
                now + 11L * 60L * 1000L);
        require(!stale.available, "messages older than 10 minutes must be rejected");

        System.out.println("ThreatRepositorySelfTest: PASS");
    }

    private static void require(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
